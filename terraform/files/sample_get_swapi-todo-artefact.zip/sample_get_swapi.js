const axios = require('axios');
const normalizeEvent = require('/opt/nodejs/normalizer');
const response = require('/opt/nodejs/response');

exports.handler = async event => {
    if (process.env.DEBUG) {
        console.log({
            message: 'Received event',
            data: JSON.stringify(event),
        });
    }

    try {
        
        const resp = await axios.get('https://swapi.py4e.com/api/people/1').catch(err=> 'Do whatever you want with the error');
        console.log({
            message: 'Records found',
            data: JSON.stringify(resp),
        });

        return response(200, data);
    } catch (err) {
        console.error(err);
        return response(500, 'Somenthing went wrong');
    }
};
